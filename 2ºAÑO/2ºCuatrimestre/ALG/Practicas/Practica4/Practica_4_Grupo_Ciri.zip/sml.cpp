//g++ -O2 -o sml sml.cpp; ./sml; rm sml
#include <string>
#include <vector>
#include <iostream>
#include <cmath>
#include <ctime>
#include <chrono>

using namespace std;


string sml(const string &x, const string &y, bool imprimir){
    string sub;
    int cont=0;
    vector<vector <int>> m ;
    vector<int>aux;
	
	if(imprimir)
		cout << endl <<  x << " " << y;
    string x2 = "x" + x;
    string y2 = "y" + y;

    for(int i=0;i<y2.size();i++){
        aux.push_back(0);
    }
    for(int i=0;i<x2.size();i++){
        m.push_back(aux);
    }


    for(int i=1; i< x2.size(); i++){
        for(int j=1; j< y2.size(); j++){
            if(x2[i]==y2[j]){
                m[i][j] = 1 + m[i-1][j-1];
            }else{
                m[i][j]=fmax(m[i-1][j],m[i][j-1]);
            }
        }
    }
    
    if(imprimir){    
		cout << endl << "  ";
		for(int i = 0; i < y2.size(); i++)
			cout << y2[i] << " ";
		cout << endl;
			
		for(int i = 0; i < x2.size(); i++){
			cout << x2[i] << " ";
		   for(int j = 0; j < y2.size(); j++){
		      cout << m[i][j] << " ";
		   }
		   cout << endl;
		}
		cout << endl;
	}
    
    cont = m[x2.size()-1][y2.size()-1];
    sub.resize(cont);
    int i = x2.size()-1, j = y2.size()-1;
    while (cont != 0) {
        if(x2[i] == y2[j])
        {
            cont--;
            sub[cont] = x2[i];
            i--; j--;
        }
        else
        {
            if(m[i-1][j] > m[i][j-1])
                i--;
            else
                j--;
        }
    }

    return sub;
}

int main(){
	int opcion;
	cout << "\n1. Introducir manualmente las cadenas" << endl
         << "2. Realizar prueba de la eficiencia" << endl
         << "\n\tElija una de las opciones anteriores: ";
	cin >> opcion;
		
	switch(opcion){
		case 1:	
		{	
			string x = "gacggattag";
			string y = "gatcggaatag";
			string a = "acbaed";
			string b = "abcadf";
			string sol = sml(x,y,true);

			cout << "La subsecuencia más larga tiene " << sol.size() << " caracteres y es: " << sol << endl;

			string sol2 = sml(a,b,true);
			cout << "La subsecuencia más larga tiene " << sol2.size() << " caracteres y es: " << sol2 << endl;
			
			if(true){
			   string primera, segunda;
			   cout << "Introduce la primera secuencia: ";
			   cin >> primera;
			   cout << "Introduce la segunda secuencia: ";
			   cin >> segunda;
			   
			   string sol3 = sml(primera,segunda,true);
			   cout << "La subsecuencia más larga tiene " << sol3.size() << " caracteres y es: " << sol3 << endl;
			}
			
			break;
		}
		case 2:
		{
			chrono::time_point<std::chrono::high_resolution_clock> ti, tf;
			double tejecucion;
			string x,y;
			int a,b;
			srand(0);
			
			for(int i = 16; i <= 32768; i = i*2){
				x = "";
				y = "";
				for(int j = 0; j < i; j++){
					a = rand()%256;
					b = rand()%256;
					x = x + (char)a;
					y = y + (char)b;
				}
				ti = std::chrono::high_resolution_clock::now();
				sml(x,y,false);
				tf = std::chrono::high_resolution_clock::now();
				tejecucion = std::chrono::duration_cast<std::chrono::microseconds>(tf - ti).count();
				cout << i << " " << tejecucion << endl;
			}
			
			
			
			break;
		}
		default:
		{
			cerr << "Opción no valida" << endl;
        	break;
        }
	}

    return 0;
}
