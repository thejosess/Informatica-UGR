#!/bin/bash

if (( $# != 1 ))
	then printf "Error de argumentos\n"
	exit 1
fi

printf "Copiando archivos a temporal...\n"
cp $1/*.gz /tmp
printf "Descomprimiendo archivos...\n"
gunzip /tmp/*.gz

read -p "Quiere ejecutarlo?(y/n)" opcion

if (( opcion == 'y' ))
	then printf "Ejecutando kernel...\n" ; /tmp/kernel32-3.0.4 ubda=/tmp/Fedora14-x86-root_fs mem=1024m
fi
