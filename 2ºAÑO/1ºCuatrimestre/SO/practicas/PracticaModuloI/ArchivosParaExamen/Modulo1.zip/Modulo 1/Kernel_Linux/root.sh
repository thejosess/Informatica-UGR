#!/bin/bash

cp /fenix/depar/lsi/UML/*.gz /tmp
printf "Archivos copiados a tmp\n"

gunzip /tmp/*.gz
printf "Archivos descomprimidos correctamente\n"

/tmp/kernel32-3.0.4 ubda=/tmp/Fedoral4-x86-root_fs men=1024m
printf "Entrando en modo root...."
