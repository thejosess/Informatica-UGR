var indexSectionsWithContent =
{
  0: "bcdegilopsv",
  1: "bcl",
  2: "bcl",
  3: "bceglops",
  4: "bcdpv",
  5: "ci",
  6: "o",
  7: "b"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "typedefs",
  6: "related",
  7: "pages"
};

var indexSectionLabels =
{
  0: "Todo",
  1: "Clases",
  2: "Archivos",
  3: "Funciones",
  4: "Variables",
  5: "typedefs",
  6: "Amigas",
  7: "Páginas"
};

