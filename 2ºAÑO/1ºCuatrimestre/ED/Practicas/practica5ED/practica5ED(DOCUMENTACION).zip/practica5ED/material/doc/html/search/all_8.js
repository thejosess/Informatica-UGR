var searchData=
[
  ['palabras_5flongitud',['palabras_longitud',['../classlista__palabras.html#a8115c53d4aac2a733128e585a778641f',1,'lista_palabras']]],
  ['puntuacion',['puntuacion',['../classletra.html#a9a751aa2a809db0ce889bf8d9f174c9c',1,'letra']]]
];
