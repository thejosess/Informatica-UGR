var searchData=
[
  ['setcaracter',['setCaracter',['../classletra.html#a9b073ebabfe6ecfa33291502511a0082',1,'letra']]],
  ['setpuntuacion',['setPuntuacion',['../classletra.html#a1fe437c38732d5e7e01a4465567bd44a',1,'letra']]],
  ['setveces',['setVeces',['../classletra.html#af48d9f423d607722cebd547b8063734b',1,'letra']]],
  ['size',['size',['../classbolsa__letras.html#a321eeff981b52782100bada7fe61ab1c',1,'bolsa_letras::size()'],['../classconjunto__letras.html#a8cc5dbb61ee93689b12445a8af652015',1,'conjunto_letras::size()'],['../classlista__palabras.html#ab901975fd828bc891eb7b498bd053436',1,'lista_palabras::size()']]]
];
