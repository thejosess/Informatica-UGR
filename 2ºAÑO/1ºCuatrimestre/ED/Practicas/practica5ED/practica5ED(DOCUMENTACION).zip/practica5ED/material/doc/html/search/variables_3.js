var searchData=
[
  ['puntuacion',['puntuacion',['../classletra.html#a9a751aa2a809db0ce889bf8d9f174c9c',1,'letra']]]
];
