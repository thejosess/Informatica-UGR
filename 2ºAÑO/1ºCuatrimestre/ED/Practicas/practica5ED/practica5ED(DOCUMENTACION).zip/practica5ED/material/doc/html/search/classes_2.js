var searchData=
[
  ['letra',['letra',['../classletra.html',1,'']]],
  ['lista_5fpalabras',['lista_palabras',['../classlista__palabras.html',1,'']]]
];
