var searchData=
[
  ['getcaracter',['getCaracter',['../classletra.html#adb09c0e08f2a0a8eb8ad97c68dae3fff',1,'letra']]],
  ['getpuntuacion',['getPuntuacion',['../classletra.html#a493feb30d95b5d7fbd7cd5c7c27cc5b8',1,'letra']]],
  ['getveces',['getVeces',['../classletra.html#a1a4793c28e00b4521136a68c06e2c5a4',1,'letra']]]
];
