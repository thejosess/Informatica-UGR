var searchData=
[
  ['datos',['datos',['../classlista__palabras.html#aadaf0fa3d11bf495196d84de631249ac',1,'lista_palabras']]]
];
