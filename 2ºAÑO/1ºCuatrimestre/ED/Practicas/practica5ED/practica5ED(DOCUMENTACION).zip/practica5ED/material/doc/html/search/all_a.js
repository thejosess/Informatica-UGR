var searchData=
[
  ['veces',['veces',['../classletra.html#abe76bc8729c210f5cf7fe48878f60d1d',1,'letra']]]
];
