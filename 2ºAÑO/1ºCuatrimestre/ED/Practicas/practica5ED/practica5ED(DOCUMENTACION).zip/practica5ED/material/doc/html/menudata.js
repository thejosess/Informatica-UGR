var menudata={children:[
{text:"Página principal",url:"index.html"},
{text:"Páginas relacionadas",url:"pages.html"},
{text:"Clases",url:"annotated.html",children:[
{text:"Lista de clases",url:"annotated.html"},
{text:"Índice de clases",url:"classes.html"},
{text:"Miembros de las clases",url:"functions.html",children:[
{text:"Todo",url:"functions.html",children:[
{text:"b",url:"functions.html#index_b"},
{text:"c",url:"functions.html#index_c"},
{text:"d",url:"functions.html#index_d"},
{text:"e",url:"functions.html#index_e"},
{text:"g",url:"functions.html#index_g"},
{text:"i",url:"functions.html#index_i"},
{text:"l",url:"functions.html#index_l"},
{text:"o",url:"functions.html#index_o"},
{text:"p",url:"functions.html#index_p"},
{text:"s",url:"functions.html#index_s"},
{text:"v",url:"functions.html#index_v"}]},
{text:"Funciones",url:"functions_func.html",children:[
{text:"b",url:"functions_func.html#index_b"},
{text:"c",url:"functions_func.html#index_c"},
{text:"e",url:"functions_func.html#index_e"},
{text:"g",url:"functions_func.html#index_g"},
{text:"l",url:"functions_func.html#index_l"},
{text:"o",url:"functions_func.html#index_o"},
{text:"p",url:"functions_func.html#index_p"},
{text:"s",url:"functions_func.html#index_s"}]},
{text:"Variables",url:"functions_vars.html"},
{text:"typedefs",url:"functions_type.html"},
{text:"Funciones relacionadas",url:"functions_rela.html"}]}]},
{text:"Archivos",url:"files.html",children:[
{text:"Lista de archivos",url:"files.html"}]}]}
