#include "lista_palabras.h"

vector<string> lista_palabras::palabras_longitud(int longitud)
{
	vector<string> v;

	for(const_iterator i = this->begin(); i != this->end(); i++)
	{
		if((*i).length() == longitud)
			v.push_back(*i);
	}

	return v;
}

istream & operator>>(istream & is, lista_palabras &D)
{
    string palabrita;
    
    while(is)
    {
    	getline(is, palabrita, '\n');
    	//cout << palabrita << "\n" ;
        D.datos.insert(palabrita);
    }

    return is;
}

ostream & operator<<(ostream & os, const lista_palabras &D)
{
    for (lista_palabras::const_iterator i = D.begin() ; i != D.end(); i++ )
    {
        os << (*i) << endl;
    }

    return os;
}

map<string,int> lista_palabras::contar_char(const conjunto_letras & conjunto, int & total) const
{
	map<string,int> swiper;

	string c1 = "ñ";
	int n = -1;
	bool entrado = false;

	/*for(conjunto_letras::iterator it = conjunto.begin(); it != conjunto.end(); it++)
	{
		swiper.insert( pair<char,int>((*it).getCaracter(), 0) );
	}*/

	for(iterator it = this->begin(); it != this->end(); it++)
	{
		if( (*it).find("ñ") != string::npos)
		{
			n = (*it).find("ñ") ;	//obtienes donde está la ñ
			entrado = true;
		}

		for(int i = 0; i < (*it).size(); i++)
		{
			string aux;
			char prueba = (*it)[i] ;
			aux = (*it)[i] ;
			if( i == n && entrado)		// si estas en la posicion de la ñ pues la metes direct
			{
				cout << c1;
				swiper[ "enye" ]++;
				i++;				//el siguiente a la ñ tambien es corrupto
			}
			else
				swiper[ aux ]++;

			total++;
		}
		entrado = false;
	}

	return swiper;
}

set<string>::iterator lista_palabras::buscar_char(char c1) const
{
    bool encontrado = false;
    iterator pos = datos.end();

    for(iterator it = datos.begin(); it != datos.end() && !encontrado; it++)
    {
        if((*it)[0] == c1)
        {
            pos = it;
            encontrado = true;
        }
    }

    return pos;
}

//yo habia pensado en hacer dos, aunque todo estaba hecho con un bool que te hace una u otra
//podriamos hacer luego otra que te diga cual es la mejor solucion o colocar desde esta funcion la mejor
//solucion de primeras o de ultimas y saberlo nosotros
set<pair<string,int>> lista_palabras::mejores_soluciones(set<pair<string, int>> soluciones, int &mejor_solucion) const
{
	//el profe decia que habia alguna forma mas eficiente de hacer esto
	//otra criba porque sabes que las que tengan letras raras sera las mejor puntuadas

	// poner la puntuacion maxima si fuese por longitud es decir la palabra mas larga del diccionario a mano o hacer funcion para ello
	//poner la puntaucion maxima si fusese por puntuacion con la puntuacion maxima que se puede obtener 
	// todo eso para luego ir hjaciendo a ese int -- si no lo encuentra 

	set<pair<string, int>> aux;

	for(set<pair<string, int>>::const_iterator it = soluciones.cbegin(); it!= soluciones.cend() ; it++ )
	{
		if(it->second == mejor_solucion)
			aux.insert((*it));
	}
	return aux;
}

set<pair<string, int>> lista_palabras::buscar_soluciones(const multiset<char> & ms_letras, const conjunto_letras & conjunto, const bool longitud) const
{
	set<pair<string, int>> soluciones;

	set<char> s_letras(ms_letras.cbegin(), ms_letras.cend());		// asi ordena y quita repetidos

	iterator j;

	for(set<char>::const_iterator i = s_letras.cbegin(); i != s_letras.cend(); i++)
	{
		j = this->buscar_char(*i);

		while((*j)[0] == *i)
		{
			if(this->es_solucion(*j, ms_letras))
			{
				soluciones.insert(make_pair(*j, conjunto.calcular_puntuacion(*j, longitud)));
				//mejor solucion hay que inicializarlo a 0
			}
			//es necesario meterlas todas?? y si cogemos solo las diez mejores y empezando por las letras que tengan mejor puntuacion
			//podriamos ordenar el multiset para asi que empiece con las que tengan mejor puntuacion o no sé

			j++;
		}
	}

	return soluciones;
}

bool lista_palabras::es_solucion(string str, const multiset<char> & ms_letras) const
{
	multiset<char> aux(ms_letras.cbegin(), ms_letras.cend());		

	bool correcto = true;

	for(int i = 0; i < str.size() && correcto; i++)
	{
		if(aux.find(str[i]) != aux.end())
			aux.erase(aux.find(str[i]));
		else
			correcto = false;
	}

	return correcto;
}