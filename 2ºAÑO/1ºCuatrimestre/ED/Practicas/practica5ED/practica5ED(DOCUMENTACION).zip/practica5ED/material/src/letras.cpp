#include <fstream>
#include <iostream>
#include "lista_palabras.h"
#include "bolsa_letras.h"

#define RED "\033[31m"

int main( int argc, char ** argv)
{

	if(argc != 5)
	{
		cerr << RED << "\nSINTAXIS INCORRECTA" << endl
			<< "Los parámetros de entrada son los siguientes:\n" <<
				"\t1. El nombre del fichero con la lista de palabras\n" <<
				"\t2. El nombre del fichero con las letras\n" <<
				"\t3. El numero de letras que se deben generar de forma aleatoria\n"<<
				"\t4. Modalidad del juego: \n"<<
				"\t - L = Longitud: Se buscará la palabras más larga \n"<<
				"\t - P = Puntuación: Se buscará la palabra de mayor puntuación" ;

		return 0;
	}

	ifstream f_lista (argv[1]);
	if (!f_lista)
	{
		cerr << RED << "ERROR ABRIENDO FICHERO: " << argv[1] << endl;
		return 0;
	}

	ifstream f_letras (argv[2]);
	if (!f_letras)
	{
		cerr << RED << "ERROR ABRIENDO FICHERO: " << argv[2] << endl;
		return 0;
	}

	bool longitud;

	if(argv[4] == "L" || argv[4] == "l")
	{
		longitud = true;
	}
	else if(argv[4] == "P" || argv[4] == "p")
	{
		longitud = false;
	}
	else
	{
		cerr << RED << "\nSINTAXIS INCORRECTA" << endl
		<< "Los parámetros de entrada son los siguientes:\n" <<
			"\t1. El nombre del fichero con la lista de palabras\n" <<
			"\t2. El nombre del fichero con las letras\n" <<
			"\t3. El numero de letras que se deben generar de forma aleatoria\n"<<
			"\t4. Modalidad del juego: \n"<<
			"\t - L = Longitud: Se buscará la palabras más larga \n"<<
			"\t - P = Puntuación: Se buscará la palabra de mayor puntuación" ;

			return 0;			
	}

	int num_aleatorio = atoi(argv[3]);

	if(num_aleatorio == 0)
	{
		cerr << RED << "\nSINTAXIS INCORRECTA" << endl
		<< "Los parámetros de entrada son los siguientes:\n" <<
			"\t1. El nombre del fichero con la lista de palabras\n" <<
			"\t2. El nombre del fichero con las letras\n" <<
			"\t3. El numero de letras que se deben generar de forma aleatoria\n"<<
			"\t4. Modalidad del juego: \n"<<
			"\t - L = Longitud: Se buscará la palabras más larga \n"<<
			"\t - P = Puntuación: Se buscará la palabra de mayor puntuación" ;

			return 0;	
	}

	lista_palabras lista;
	conjunto_letras conjunto;

	f_lista >> lista; 
	f_letras >> conjunto;
	f_lista.close();
	f_letras.close();


	bolsa_letras bolsa(conjunto);

	multiset<char> ms_letras;

	for(int i = 0 ; i < num_aleatorio ; i++)
	{
		ms_letras.insert(bolsa.coger_letra());
	}

	cout << "\nBIENVENIDO AL JUEGO DE LAS LETRAS DE RAY Y JOSÉ\n";
	cout << "---------------------------------------------------\n";

	bool seguir_jugando = true;


	while(seguir_jugando)
	{
			cout << "Las letras son: " ;

			for(multiset<char>::const_iterator it = ms_letras.cbegin(); it != ms_letras.cend(); it++)
			{
				cout << (*it) << "\t\t\t" ;
			}

			string solucion_user;

			cout <<"\nDime tu solucion:";
			cin >> solucion_user;

			int puntuacion = conjunto.calcular_puntuacion(solucion_user, longitud);
			cout << solucion_user <<  "\n\t" << puntuacion << endl;

			set<pair<string, int>> soluciones = lista.buscar_soluciones(ms_letras, conjunto,  longitud);
			cout << "Mis soluciones son:\n";

			set<pair<string, int>>::const_iterator it = soluciones.end();

			for(int i = 0 ; i < 6 ; i++)
			{
				it--;
			}

			for(it; it != soluciones.end() ; it++)
			{
				cout << it->first << "\t" << "Puntuacion: " << it->second << endl;
			}

			it = soluciones.end();
			it--;

			cout <<"Mejor solucion:" << it->first << endl;

			char jugar ;

			do
			{
				cout <<"¿Quieres seguir jugando[S/N]?" << endl;
				cin >> jugar;

			}while(jugar != 'N' || jugar != 'n' || jugar != 'S' || jugar != 's') ;

			if(jugar == 'N' )
				seguir_jugando = false;
	}
	
	


	/*else if(argv[4] == "P")
	{
		while(seguir_jugando)
		{
			cout << "Las letras son: "
			//for(bolsa_letras::const_iterator it = bolsa.begin(); it != bolsa.end() ; it++)
			//	cout << (*it) << "\t\t\t";

			for(multiset<char> const_iterator it = ms_letras.begin(); it != it.end(); it++)
			{
				cout << (*it) << "\t\t\t" ;
			}

			string solucion_user;

			cout <<"\nDime tu solucion:";
			cin >> solucion_user;

			int puntuacion = conjunto.calcular_puntuacion(solucion_user);
			cout << solucion_user <<  "\n\t" << puntuacion << endl;

			int mejor_solucion = 0;
			set<pair<string, int>> soluciones = lista.buscar_soluciones(ms_letras, conjunto,  false, mejor_solucion);
			set<pair<string, int>> mejores_soluciones = lista.mejores_soluciones(soluciones,mejor_solucion);
			cout << "Mis soluciones son:\n"

			for(set<pair<string, int>>::const_iterator it = mejores_soluciones.begin(); it != mejores_soluciones.end() ; it++)
			{
				cout << it->first << "\t" << "Puntuacion: " << it->second << endl;
			}

			cout << "Mejor solucion:" << mejores_soluciones.begin() << endl;

			string jugar ;

			cout <<"¿Quieres seguir jugando[S/N]?" << endl;
			cin >> jugar;

			if(jugar == "N")
				seguir_jugando = false;
		}
	}*/
}