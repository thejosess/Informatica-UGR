#ifndef COLAMAX
#define COLAMAX

#include <iostream>
#include <utility>
#include <stack>

using namespace std;

template <typename T>
class Cola_max
{
private:
	stack< pair<T,T> > primera;
	stack< pair<T,T> > segunda;
public:
	inline Cola_max(){ int x = 2+3; };

	void push(const T& elemento);

	void pop();

	bool empty();

	int size();

	T front();

	T back();

	T maximo();
};

#endif