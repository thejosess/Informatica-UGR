var searchData=
[
  ['getdefiniciones',['getDefiniciones',['../classDiccionario.html#aad03ce4c1b817f8479187631415d16fe',1,'Diccionario::getDefiniciones()'],['../classTermino.html#a5fd3e7725f762ea79b7f153fff8448e9',1,'Termino::getDefiniciones()']]],
  ['getnumdefiniciones',['getNumDefiniciones',['../classTermino.html#a8282191c52b4c28ff5beda0d78cb9a7b',1,'Termino']]],
  ['getnumterminos',['getNumTerminos',['../classDiccionario.html#ae6d984ee1c3d6efa0748ef9708e6959c',1,'Diccionario']]],
  ['getpalabra',['getPalabra',['../classTermino.html#aca7e4f7a65e39d79ce59be80c6b88690',1,'Termino']]],
  ['getterminos',['getTerminos',['../classDiccionario.html#a85e5db548f049f0299af83816ce95ba0',1,'Diccionario']]]
];
