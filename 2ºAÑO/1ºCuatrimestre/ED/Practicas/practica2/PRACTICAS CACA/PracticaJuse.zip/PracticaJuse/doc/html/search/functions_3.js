var searchData=
[
  ['diccionario',['Diccionario',['../classDiccionario.html#aa0a2191ec706b256c35b5229cc197b15',1,'Diccionario::Diccionario()'],['../classDiccionario.html#a67f1a05f8323a0d0d7b8049069c8d46f',1,'Diccionario::Diccionario(const Vector_Dinamico&lt; Termino &gt; &amp;terminos)'],['../classDiccionario.html#aac6fd75d8050f0c95b084522be0c8d72',1,'Diccionario::Diccionario(const Diccionario &amp;dicc)']]]
];
