var searchData=
[
  ['cargardefichero',['CargarDeFichero',['../classDiccionario.html#ae37735a3179667c8ba3dc1adde186c24',1,'Diccionario']]]
];
