var searchData=
[
  ['operator_3c_3c',['operator&lt;&lt;',['../classDiccionario.html#aa3c33fedde004056e897f3afd93e16d6',1,'Diccionario::operator&lt;&lt;()'],['../classTermino.html#a1293e09e89b249a12c360ee2de98793a',1,'Termino::operator&lt;&lt;()']]],
  ['operator_3e_3e',['operator&gt;&gt;',['../classDiccionario.html#a45c4223c6616bbe06f8e1aff14d06563',1,'Diccionario::operator&gt;&gt;()'],['../classTermino.html#a616bdafcef17bf554e65ea780252f139',1,'Termino::operator&gt;&gt;()']]]
];
