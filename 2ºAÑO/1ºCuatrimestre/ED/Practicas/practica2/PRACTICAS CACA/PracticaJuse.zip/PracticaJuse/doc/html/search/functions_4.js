var searchData=
[
  ['filtrarporintervalo',['FiltrarPorIntervalo',['../classDiccionario.html#a76ab6696236506f2588ada8c48b65e7f',1,'Diccionario']]],
  ['filtrarporpalabra',['FiltrarPorPalabra',['../classDiccionario.html#a624d7626bc2edfc9c079f22184c2aea6',1,'Diccionario']]]
];
