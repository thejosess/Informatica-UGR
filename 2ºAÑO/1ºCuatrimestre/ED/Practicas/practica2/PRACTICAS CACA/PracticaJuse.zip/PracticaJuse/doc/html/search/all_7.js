var searchData=
[
  ['recuentodefiniciones',['RecuentoDefiniciones',['../classDiccionario.html#ac393fbdc7061cb322675e9926b881481',1,'Diccionario']]],
  ['rmtermino',['rmTermino',['../classDiccionario.html#a1bff2743fd2005d30c46d4494a1a3fd0',1,'Diccionario']]]
];
