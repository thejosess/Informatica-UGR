var searchData=
[
  ['salvarafichero',['SalvarAFichero',['../classDiccionario.html#aaa5064e87e9cf39a82e9c1e227ede399',1,'Diccionario']]],
  ['setdefinicion',['setDefinicion',['../classTermino.html#a4412fc8c5a55129f9ce3ae5ded5005a4',1,'Termino']]],
  ['setdefiniciones',['setDefiniciones',['../classTermino.html#a463e17034df9a1bf12ac2df32113ebf6',1,'Termino']]],
  ['setdiccionario',['setDiccionario',['../classDiccionario.html#a09d7923857d54842a4cb69fc9fcadf4b',1,'Diccionario']]],
  ['setpalabra',['setPalabra',['../classTermino.html#a62ab7aa09c2e230ad52eff14554d9fc7',1,'Termino']]]
];
