var searchData=
[
  ['termino',['Termino',['../classTermino.html#ac3b1425fec4d38d78c5d36cb5fe8e728',1,'Termino::Termino()'],['../classTermino.html#a73baeaf5d990acd1772d325582fd95f4',1,'Termino::Termino(string palabra, Vector_Dinamico&lt; string &gt; definiciones)'],['../classTermino.html#a28543208f4f4a85683e0a373713a3243',1,'Termino::Termino(const Termino &amp;term)']]]
];
