var searchData=
[
  ['operator_3d_3d',['operator==',['../classTermino.html#a021703bece66709157c3835346e15c34',1,'Termino']]]
];
