#ifndef TERMINO
#define TERMINO

#include <iostream>
#include <fstream>
#include <vector>

using namespace std;

class Termino
{
private:

    pair<string, vector<string>> termino;

public:

    typedef vector<string>::iterator iterator;
    typedef vector<string>::const_iterator const_iterator;

    inline Termino::iterator begin(){return termino.second.begin();};
    inline Termino::const_iterator begin()const {return termino.second.cbegin();} ;
    inline Termino::iterator end(){return termino.second.end();};
    inline Termino::const_iterator end() const {return termino.second.cend();} ; 


        /**
         * @brief Constructor por defecto 
         */
	inline Termino(){};

        /**
         * @brief Constructor con parametros
         * @param palabra le pasas una palabra como parametro para construir un Termino
         * @param definiciones le pasas unas definiciones como parametro para construir un Termino
         */
	inline Termino(string palabra, vector<string> definiciones){ this->termino.first = palabra; this->termino.second = definiciones; };
        
        /**
         * @brief Constructor con un parametro termino
         * @param term termino pasado para construir un Termino
         */
	inline Termino(const Termino & term){ this->termino.first = term.termino.first; this->termino.second = term.termino.second; };
        
        /**
         * @brief Devuelve una palabra
         * @return palabra devuelves la palabra de Termino
         */
	inline string getPalabra() const { return termino.first ; };
        
        /**
         * @brief Devuelve las definiciones
         * @return definiciones devuelves las definiciones asociadas de Termino
         */
	inline vector<string> getDefiniciones() const { return this->termino.second; };
        
        /**
         * @brief Devuelve el numero de definiciones    
         * @return definiciones.size() devuelves el tamaño de las definiciones de termino
         */
	inline int getNumDefiniciones() const { return termino.second.size(); };
        
        /**
         * @brief Asigna una palabra pasada por parametro a palabra
         * @param palabra se le pasa una palabra que asgina a palabra
         */
	inline void setPalabra(string palabra){ this->termino.first = palabra; };
        
        /**
         * @brief Aisgna definiciones pasadas por parametro a las definiciones
         * @param definiciones que se le asigna a definiciones
         */
	inline void setDefiniciones(vector<string> definiciones){ this->termino.second = definiciones; };
        
        /**
         * @brief Asignacion de una definicion pasada por parametro a la definicion
         * @param definicion que se le asigna a definicion 
         */
	inline void addDefinicion(string definicion){ this->termino.second.push_back(definicion); };
        
        /**
         * @brief Asignacion de una definicion pasada por parametro a la definicion
         * @param definicion que se le asigna a definicion 
         */
    void setDefinicion(string definicion);
        
        /**
         * @brief Sobrecarga del operador de igualdad
         * @return @true si son iguales los terminos @false si son distintos
         */
    bool operator==(const Termino& termino);
        
        /**
         * @brief Sobrecarga del operador >> 
         * @return devuelve el operador de flujo de entrada
         */
	friend istream& operator>>(istream& is, Termino& term);
        
       /**
         * @brief Sobrecarga del operador de entrada
         * @return devuelve el operador de flujo de entrada
         */
	friend ostream& operator<<(ostream& os, const Termino& term);

        /**
         * @brief Sobrecarga del operador de menor
         * @return @true si es menor respecto al que le pasas @false en caso contrario
         */
    bool operator<(const Termino &termino) const;
};

#endif
