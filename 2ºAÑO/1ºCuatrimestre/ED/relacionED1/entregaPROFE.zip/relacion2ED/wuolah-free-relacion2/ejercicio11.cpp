#include <iostream>
#include <string>
#include <queue>
#include <stack>


using namespace std;

struct name
{
	string nombre;
	string apellidos;
	int prioridad;
};

class prioridad
{
public:
	bool operator() (name nombre1, name nombre2)
	{
		if(nombre1.prioridad > nombre2.prioridad)
			return true;
		else
			return false;
	}
};
int main()
{
	priority_queue<name,vector<name>,prioridad> cola;

	name nombre1, nombre2, nombre3 ;
	nombre1 = {"Jose", "Santos Salvador", 3};
	nombre2 = {"Jose", "Santos Salvador", 4};
	nombre3 = {"Jose", "Santos Salvador", 5};

	cola.push(nombre1);
	cola.push(nombre2);
	cola.push(nobmre3);





}