/*
Usando una pila y una cola, implementa una función que compruebe si un string es 
un palı́ndromo.
*/

#include <iostream>
#include <string>
#include <stack>
#include <queue>

using namespace std;


bool es_palindromo (string frase){
	stack<char> pila;
	queue<char> cola;
	
	for (int i=0; i < frase.size(); i++){
		pila.push(frase[i]);
		cola.push(frase[i]);
	}

	for (int i=0; i < frase.size(); i++){
		if(pila.top() == cola.front()){
			pila.pop();
			cola.pop();
		}
		else return false;
	}

	return true;
}

int main(){

	string frase;
	cin >> frase;

	cout << "¿Es palindromo? " << es_palindromo(frase) << endl;
	
	return(0);
}
