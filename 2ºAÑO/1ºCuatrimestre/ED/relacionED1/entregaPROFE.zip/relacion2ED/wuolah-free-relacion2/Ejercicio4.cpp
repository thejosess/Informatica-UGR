/*
Implementa el TDA pila usando dos colas.
*/

#include <iostream>
#include <queue>

using namespace std;

template<typename T>

class Pila{
private:
	queue<T> cola, cola_aux;
public:
	bool empty() const{
		return cola.empty();
	}

	size_t size() const{
		return cola.size();
	}

	T& top(){
		return cola.back();
	}

	const T& top() const{
		return cola.back();
	}

	void push(const T& nombredevariable){
		cola.push(nombredevariable);
	}

	void pop(){
		while(cola.size() != 1){
			cola_aux.push(cola.front());
			cola.pop();
		}
		cola.pop();
		while (!cola_aux.empty()){
			cola.push(cola_aux.front());
			cola_aux.pop();
		}
	}
};

int main(){

	Pila<int> enteros;

	enteros.push(1);
	enteros.push(2);
	enteros.push(3);
	enteros.push(4);

	while (!enteros.empty()){
		cout << "top() " << enteros.top() << endl;
		cout << "size() " << enteros.size() << endl;

		enteros.pop();
	}
	return(0);
}

