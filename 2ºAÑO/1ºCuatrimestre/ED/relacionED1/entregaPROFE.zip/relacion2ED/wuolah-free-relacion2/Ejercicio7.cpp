/*
	Se llama expresión en postfijo a una expresión matemática en la que cada 
	operación aparece con sus dos operandos seguidos por el operador. 
	Por ejemplo: 2 3 + 5 * Escribe un programa que evalue una expresión en 
	postfijo.
*/

#include <iostream>
#include <string>
#include <stack>
#include <queue>

using namespace std;



string evalua(string e)
{
	stack<string> v;
	unsigned i;
	string dcha, izq;

	for(i=0; i<e.size();++i){
		if((e[i] >= 'a') && (e[i] <= 'z'))
			v.push(string(1,e[i]));
		else{
			dcha = v.top();
			v.pop();
			izq = v.top();
			v.pop();
			
			switch(e[i]){
				case '+':
					v.push(izq+'+'+dcha);
				break;
				case '-':
					v.push(dcha+'-'+izq);
				break;
				case '*':
					v.push(izq+'*'+dcha);
				break;
				case '/':
					v.push(izq+'/'+dcha);
				break;
				case '^':
					v.push(izq+'^'+dcha);
				break;
			}
		}
	}
	return v.top();
	
}

int main(){
	string expresion;
	cin >> expresion;

	cout << "El resultado es " << evalua(expresion) << endl;

	return(0);
}
