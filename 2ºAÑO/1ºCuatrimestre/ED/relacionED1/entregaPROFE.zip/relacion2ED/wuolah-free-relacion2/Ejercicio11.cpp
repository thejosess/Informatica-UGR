/*
	Un tipo ventana es un tipo de dato que permite insertar un elemento, mover 
	derecha, mover izquierda, borrar elemento y que se implementa usando dos 
	pilas. Implementa ese tipo de dato con las operaciones comentadas.
*/
#include <iostream>
#include <stack>
#include <string>

using namespace std;

template<typename T>
class Ventana{
private:

	stack<T> pila, pila_aux;

public:

void Insertar(T x){
	pila.push(x);
}

void MoverIzquierda(){
	pila.push(pila_aux.top());
	pila_aux.pop();
}

void MoverDerecha(){
	pila_aux.push(pila.top());
	pila.pop();
}

void Eliminar(){
	pila.pop();
}

void MostrarIzquierda(){
	while(!pila.empty()){
		cout << pila.top() << endl;
		pila.pop();
	}
}

void MostrarDerecha(){
		while(!pila_aux.empty()){
		cout << pila_aux.top() << endl;
		pila_aux.pop();
	}
}
};

int main(){

	Ventana<char> frase;

	frase.Insertar('e');
	frase.Insertar('p');
	frase.Insertar('e');
	frase.Insertar('p');

	cout << "Izquierda: \n";
	frase.MostrarIzquierda();

	frase.Insertar('e');
	frase.Insertar('p');
	frase.Insertar('e');
	frase.Insertar('p');

	frase.MoverDerecha();
	frase.MoverIzquierda();
	
	cout << "Izquierda: \n";
	frase.MostrarIzquierda();
	cout << "Derecha: \n";
	frase.MostrarDerecha();
	
	frase.Insertar('e');
	frase.Insertar('p');
	frase.Insertar('e');
	frase.Insertar('p');

	frase.Eliminar();
	
	cout << "Izquierda: \n";
	frase.MostrarIzquierda();
	
	
	return(0);
}



