/*
Implementa una función para determinar si una expresión contenida en un string 
tiene una configuración de paréntesis correcta. Debe tener un orden lineal.
*/

#include <iostream>
#include <string>
#include <stack>
using namespace std;

bool ParentesisCorrectos (string frase)
{
	stack<char> pila;
	bool correcto = false;
	char simbolo1 = '(';
	char simbolo2 = ')';

	for (unsigned i=0; i<frase.size(); ++i){
			if (frase[i] == simbolo1){
				pila.push(simbolo1);
			}
			else if (frase[i] == simbolo2){
				if (pila.empty())
					return false;
				else{
					pila.pop();
				}
			}
	}
	return (pila.empty());

}

int main(){

	string frase;
	cin >> frase;
	cout << ParentesisCorrectos(frase) << endl;

	return 0;
}
