/*
	Implementa una función insertar(Q, pos, x) que inserte un elemento en una 
	cola Q en la posición pos.
	La cola debe quedar como estaba antes de insertar el elemento (salvo por el 
	nuevo elemento)
*/

#include <iostream>
#include <queue>

using namespace std;

template<typename T>

void Insertar(queue<T>& cola, int pos, T x){
	queue<T> cola_aux;
	int cont = 0;
	while(!cola.empty()){
		if(cont == pos)
			cola_aux.push(x);
		else{
			cola_aux.push(cola.front());
			cola.pop();
		}
		
		++cont;
	}

	while(!cola_aux.empty()){
		cola.push(cola_aux.front());
		cola_aux.pop();
	}
}
int main(){
	queue<int> enteros;

	enteros.push(0);
	enteros.push(1);
	enteros.push(2);
	enteros.push(4);
	enteros.push(5);

	cout << "Cola nueva" << endl;
    Insertar(enteros,0,3);
	while(!enteros.empty()){
		cout << enteros.front() << endl;
		enteros.pop();
	}

}

