/*
	Implementa una función insertar(P, pos, x) que inserte un elemento en una 
	pila P en la posición pos.
	La pila debe quedar como estaba antes de insertar el elemento (salvo por el 
	nuevo elemento)
*/

#include <iostream>
#include <stack>

using namespace std;

template<typename T>

void Insertar(stack<T>& pila, int pos, T x){
	stack<T> pila_aux;
	int cont = pila.size()-1;
	while(!pila.empty()){
		pila_aux.push(pila.top());
		pila.pop();
		if(cont == pos)
			pila_aux.push(x);
		--cont;
	}

	while(!pila_aux.empty()){
		pila.push(pila_aux.top());
		pila_aux.pop();
	}
}

int main(){
	
		stack<int> enteros;

	enteros.push(0);
	enteros.push(1);
	enteros.push(2);
	enteros.push(4);
	enteros.push(5);

	cout << "Pila nueva" << endl;
    Insertar(enteros,3,3);
	while(!enteros.empty()){
		cout << enteros.top() << endl;
		enteros.pop();
	}

}

