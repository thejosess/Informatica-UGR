/*
Diremos que una pila es válida si sus elementos cumple la condicion de estar 
ordenados segun el orden indicado en una cola. Por ejemplo, si el tope es la 
posición 0 y tenemos la pila < 7, 23, 1, 6, 9 > y la cola <2, 3,0,4,1 >. 
Implementa una función bool valida(const stack<T> &P, const queue<int> &Q) que 
verifique si una pila es válida
*/

#include <iostream>
#include <stack>
#include <queue>

using namespace std;

template<typename T>

bool valida(const stack<T> &P, const queue<int> &Q){
	stack<T> pila_aux=P;
	queue<int> cola_aux=Q;
	int cont = P.size()-1;
	int x = -1;
	bool valida=true;

	while(!cola_aux.empty()){
		if(cont == cola_aux.front()){
			if(x < pila_aux.top()){					
				x=pila_aux.top();
				cout << "Elemento: " << x << endl;
				cola_aux.pop();	
				pila_aux=P;		
				cont=P.size()-1;
			}
			else return false;
		}
		else{
			pila_aux.pop();	
			--cont;
		}
	}
	return valida;
}

int main(){

	stack<int> enteros;

	enteros.push(7);
	enteros.push(23);
	enteros.push(1);
	enteros.push(6);
	enteros.push(9);

	queue<int> posicion;
	posicion.push(2);
	posicion.push(3);
	posicion.push(0);
	posicion.push(1);
	posicion.push(4);

	cout << "¿Es valida la pila? " << valida(enteros,posicion) << endl;

	stack<int> enteros2;

	enteros2.push(7);
	enteros2.push(23);
	enteros2.push(1);
	enteros2.push(6);
	enteros2.push(9);

	queue<int> posicion2;
	posicion2.push(2);
	posicion2.push(3);
	posicion2.push(0);
	posicion2.push(4);
	posicion2.push(1);

	cout << "¿Es valida la pila? " << valida(enteros2,posicion2) << endl;
	
	return(0);
}

