/*
	Dada una matriz que representa un laberinto, construye una función que 
	determine si se puede llegar desde la entrada hasta la salida. Esta matriz 
	tendrá una ’E’ en la entrada, una ’S’ en la salida, un ’0’ en las casillas 
	por las que se pueda pasar y un ’1’ en las que no. No se puede ir en 
	diagonal.
*/

#include <iostream>
#include <string>
#include <stack>

using namespace std;
const int TAM=20;

typedef struct{
	int fila;
	int columna;
	bool activado;
}POSICION;
bool TieneSolucion(char matriz[][TAM]){
	stack<POSICION> pila;
	bool activo[TAM][TAM];
		
	for(int i=0; i<TAM; ++i)
		for(int j=0; j<TAM; ++j)
			activo[i][j]=false;

	for(int i=0; i<TAM; ++i)
		for(int j=0; j<TAM; ++j)
			if(matriz[i][j]=='E'){
				pila.push({i,j,false});
				activo[i][j]=true;
			}
	if(pila.empty())
		return false;

	while(!pila.empty()){
		int fila, columna;
		fila = pila.top().fila;
		columna = pila.top().columna;
		if(!pila.top().activado){
			cout << "Abrir Size " << pila.size() << " Fila " << pila.top().fila 
				 << " Columna " << pila.top().columna << endl;
			pila.top().activado=true;
			if(pila.top().columna+1 <= TAM-1){
				if(matriz[fila][columna+1] == '0' &&
					!activo[fila][columna+1]){
					pila.push({fila,columna+1,false});
					activo[fila][columna+1]=true;
				}
				else if(matriz[fila][columna+1] == 'S')
					return true;
			}
				cout << "Size " << pila.size() << " Fila " << pila.top().fila 
				 << " Columna " << pila.top().columna << endl;
			if(pila.top().fila+1 <= TAM-1){
				if(matriz[fila+1][columna] == '0' &&
					!activo[fila+1][columna]){
					pila.push({fila+1,columna,false});
					activo[fila+1][columna]=true;
				}
				else if(matriz[fila+1][columna] == 'S')
					return true;
			}
				cout << "Size " << pila.size() << " Fila " << pila.top().fila 
				 << " Columna " << pila.top().columna << endl;
			if(pila.top().columna-1 >= 0){
				if(matriz[fila][columna-1] == '0' &&
					!activo[fila][columna-1]){
					pila.push({fila,columna-1,false});
					activo[fila][columna-1]=true;
				}
				else if(matriz[fila][columna-1] == 'S')
					return true;
			}
					cout << "Size " << pila.size() << " Fila " << pila.top().fila 
				 << " Columna " << pila.top().columna << endl;
			if(pila.top().fila-1 >= 0){
				if(matriz[fila-1][columna] == '0' &&
					!activo[fila-1][columna]){
					pila.push({fila-1,columna,false});
					activo[fila-1][columna]=true;
				}
				else if(matriz[fila-1][columna] == 'S')
					return true;
			}
			cout << "Size " << pila.size() << " Fila " << pila.top().fila 
				 << " Columna " << pila.top().columna << endl;
			
		}
		else
			pila.pop();
	}	
	return false;
}
int main(){
	char matriz[TAM][TAM] { {'E','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0'},
							{'1','0','1','0','1','0','1','1','0','1','1','1','0','0','0','0','1','1','1','0'},
							{'1','0','1','0','1','0','1','1','0','1','1','1','0','0','0','0','1','1','1','0'},
							{'1','0','1','0','1','0','1','1','0','1','1','1','0','0','0','0','1','1','1','0'},		
							{'1','0','1','0','1','0','1','1','0','1','1','1','0','0','0','0','1','1','1','0'},
							{'1','0','1','0','1','0','1','1','0','1','1','1','0','0','0','0','1','1','1','0'},
							{'0','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0'},
							{'1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0'},
							{'1','0','1','0','1','0','1','1','0','1','1','1','0','0','0','0','1','1','1','0'},
							{'1','0','1','0','1','0','1','1','0','1','1','1','0','0','0','0','1','1','1','0'},
							{'1','0','1','0','1','0','1','1','0','1','1','1','0','0','0','0','1','1','1','0'},		
							{'1','0','1','0','1','0','1','1','0','1','1','1','0','0','0','0','1','1','1','0'},
							{'1','0','1','0','1','0','1','1','0','1','1','1','0','0','0','0','1','1','1','0'},
							{'0','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0'},
							{'1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0'},
							{'1','0','1','0','1','0','1','1','0','1','1','1','0','0','0','0','1','1','1','0'},
							{'0','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0'},
							{'1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0'},
							{'1','0','1','0','1','0','1','1','0','1','1','1','0','0','0','0','1','1','1','0'},
							{'S','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0'}};
					

	
	for(int i=0; i< TAM;++i){
		for(int j=0; j< TAM; ++j)
				cout << matriz[i][j] << " ";
		cout << endl;
	}

	cout << "¿Tiene solucion?: " << TieneSolucion(matriz) << endl;
}
