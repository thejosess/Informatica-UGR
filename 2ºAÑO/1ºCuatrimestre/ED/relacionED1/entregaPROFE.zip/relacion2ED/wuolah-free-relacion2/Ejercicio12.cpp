/*
	Implementa una cola con prioridad de un tipo struct con (apellidos, nombre, 
	prioridad) de forma que los datos salgan de acuerdo a ese tercer campo 
	prioridad.
*/

#include <iostream>
#include <vector>
#include <string>
#include <queue>

using namespace std;
typedef struct {
	string apellidos;
	string nombre;
	int prioridad;
}NOMBRE;
struct pri {
  bool operator() (NOMBRE a, NOMBRE b)
  {
    return(a.prioridad > b.prioridad);
  }
};

int main()
{
  priority_queue<NOMBRE, vector<NOMBRE>, pri > pq;
    pq.push({"Rodríguez Martínez","Maria",1});
	pq.push({"López Fernández","Alba",5});
	pq.push({"Pérez Fernández","Nazaret",2});
	pq.push({"Gómez Martínez","Natalia",3});
	pq.push({"Gómez López","Teresa",4});

  while (!pq.empty()) {
    cout << pq.top().apellidos << " " << pq.top().nombre << endl;
    pq.pop();
  }
  cout << endl;
}
