/*
	Implementa una cola con prioridad que contenga strings y de la que salgan 
	primero las cadenas de caracteres que tengan más vocales y que en caso de 
	igualdad salgan por orden alfabético.
*/

#include <iostream>
#include <algorithm>
#include <vector>
#include <string>
#include <queue>

using namespace std;


struct pri {
  bool operator() (string a, string b)
  {
	int prioridad_a = 0;
	int prioridad_b = 0;
	
	transform(a.begin(), a.end(), a.begin(), ::tolower);
	transform(b.begin(), b.end(), b.begin(), ::tolower);

	for (int i =0; i< a.size(); i++)
		if( a[i] == 'a' || a[i] == 'e' || a[i] == 'i' ||
			a[i] == 'o' || a[i] == 'u')
			prioridad_a++;
	for (int i =0; i< b.size(); i++)
		if( b[i] == 'a' || b[i] == 'e' || b[i] == 'i' || 
			b[i] == 'o' || b[i] == 'u')
			prioridad_b++;
	
	if(prioridad_a == prioridad_b)
		return (a <b);
    return(prioridad_a < prioridad_b);
  }
};

int main()
{
  priority_queue<string, vector<string>, pri > pq;
    pq.push("Rodríguez Martínez Maria");
	pq.push("López Fernández Alba");
	pq.push("Pérez Fernández Nazaret");
	pq.push("Gómez Martínez Natalia");
	pq.push("Gómez López Teresa");

  while (!pq.empty()) {
    cout << pq.top() << endl;
    pq.pop();
  }
  cout << endl;

  
}
