/*
Construye una función a la que se se le pase una pila P de tipo T y dos 
elementos x,y de tipo T y que modifique la pila de forma que todas las veces que
aparezca x se substituya por y (quedando la pila en el mismo estado en el que 
estaba anteriormente)
*/

#include <iostream>
#include <stack>
using namespace std;

template<typename T>
void CambiaXporY(stack<T>& pila, T x, T y)
{
	stack<T> pila_aux;
	while(!pila.empty()){
		if(pila.top() == x)
			pila.top() = y;
		pila_aux.push(pila.top());
		pila.pop();
	}

	while(!pila_aux.empty()){
		pila.push(pila_aux.top());
		pila_aux.pop();
	}
	
}

int main(){
	stack<int> enteros;

	enteros.push(1);
	enteros.push(2);
	enteros.push(3);
	enteros.push(4);

	cout << "Pila nueva" << endl;
    CambiaXporY(enteros,2,3);
	while(!enteros.empty()){
		cout << enteros.top() << endl;
		enteros.pop();
	}
}
	
